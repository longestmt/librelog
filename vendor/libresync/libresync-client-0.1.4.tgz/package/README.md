# @libresync/client

Browser-safe ESM client for the LibreSync encrypted operation protocol. It installs five namespaced
stores in an application's existing IndexedDB database, records domain changes and causal outbox
state atomically, persists exact encrypted retry envelopes, applies remote materialization without
echo, and exposes vault/pairing/device/conflict lifecycle APIs.

```js
import { IndexedDbSecretStorage, LibreSyncClient, installLibreSyncStores } from "@libresync/client";
```

Call `installLibreSyncStores(db, upgradeTransaction)` from the application's own IndexedDB upgrade.
Construct `LibreSyncClient` with the existing database, all domain store names a remote operation
may touch, a validate-first direct domain adapter, stable application/device IDs, and a
`SecretStorage` implementation.

Local writes call `client.recordLocalOperation` inside the same transaction as domain puts/deletes.
Remote `sync()` decrypts outside transactions, then commits domain projection, heads, conflicts,
inbox, and opaque continuation together. Pending work stays available offline; a lost response
reuses the exact persisted nonce and ciphertext.

```js
const client = new LibreSyncClient({
  applicationId: "org.libresuite.example",
  appSchemaVersion: 1,
  deviceId: crypto.randomUUID(),
  deviceLabel: "Laptop",
  db: openApplicationDatabase,
  domainStores: ["records", "settings"],
  applyMaterialized,
  secretStorage: new IndexedDbSecretStorage(openApplicationDatabase, "example")
});

await client.createVault({ serverUrl: "https://sync.example.com" });
await client.sync();
```

The lifecycle API includes vault creation/join, bootstrap and reconciliation, status subscriptions,
pairing invitations, device listing/revocation, conflict listing/resolution, disconnection, and
separately confirmed permanent vault deletion. `maxChangesPerOperation` controls plaintext atomic
operation size (at most 256); `maxPushBatchOperations` independently defaults to 100 envelopes so
the shipped client interoperates with the default Docker server quota.

The supplied `IndexedDbSecretStorage` is protected only by the browser origin/profile. Applications
with a native keystore should provide a stronger implementation. Portable backups must exclude all
`libresync_*` stores and every vault secret, credential, invitation, and cursor.

Full contracts and examples are in [`docs/INTEGRATION.md`](../../docs/INTEGRATION.md). Protocol and
security details are in [`docs/PROTOCOL.md`](../../docs/PROTOCOL.md) and
[`docs/SECURITY.md`](../../docs/SECURITY.md).
