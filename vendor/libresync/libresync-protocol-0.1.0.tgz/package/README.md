# @libresync/protocol

Browser-safe TypeScript primitives for LibreSync operations, dotted-version-vector reduction,
deterministic conflict projection, and end-to-end encrypted relay envelopes.
