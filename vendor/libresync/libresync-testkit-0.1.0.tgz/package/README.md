# @libresync/testkit

An in-memory LibreSync relay, fixture builders, seeded shuffling, and transport fault injection for
application integration tests.
